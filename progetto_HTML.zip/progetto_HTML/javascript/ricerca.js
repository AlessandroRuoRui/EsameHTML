// ricerca.js
document.addEventListener('DOMContentLoaded', function() {
  // Elementi DOM
  const searchInput = document.getElementById('searchInput');
  const searchButton = document.getElementById('searchButton');
  const filtersToggle = document.getElementById('filtersToggle');
  const filtersContainer = document.getElementById('filtersContainer');
  const resetFilters = document.getElementById('resetFilters');
  const applyFilters = document.getElementById('applyFilters');
  const searchResults = document.getElementById('searchResults');
  
  // Database dei prodotti con immagini
  const prodotti = [
    { nome: "Scarico Sportivo Inox", categoria: "scarichi", prezzo: 250, marca: "akrapovic", descrizione: "Acciaio inox, prestazioni migliorate e sound potente.", immagine: "../immagini/scarico-inox.jpg" },
    { nome: "Terminale Racing", categoria: "scarichi", prezzo: 180, marca: "akrapovic", descrizione: "Design sportivo e leggerezza per auto da competizione.", immagine: "../immagini/terminale-racing.jpg" },
    { nome: "Impianto Completo Performance", categoria: "scarichi", prezzo: 450, marca: "akrapovic", descrizione: "Massima resa e stile per la tua auto sportiva.", immagine: "../immagini/scarico-completo.jpg" },
    { nome: "Filtro Aria Sportivo a Pannello", categoria: "filtri-aria", prezzo: 75, marca: "kn", descrizione: "Più flusso d'aria e maggiore efficienza del motore.", immagine: "../immagini/filtro-pannello.jpg" },
    { nome: "Filtro a Cono Universale", categoria: "filtri-aria", prezzo: 90, marca: "kn", descrizione: "Facile da installare, prestazioni migliorate su ogni veicolo.", immagine: "../immagini/filtro-cono.jpg" },
    { nome: "Filtro Aria Inox", categoria: "filtri-aria", prezzo: 120, marca: "kn", descrizione: "Struttura metallica riutilizzabile, ideale per elaborazioni.", immagine: "../immagini/filtro-inox.jpg" },
    { nome: "Molle Ribassate", categoria: "assetti", prezzo: 210, marca: "koni", descrizione: "Acciaio inox, prestazioni migliorate e tenuta di strada migliorata.", immagine: "../immagini/molle-ribassate.jpg" },
    { nome: "Coilover Regolabili", categoria: "assetti", prezzo: 850, marca: "koni", descrizione: "Prestazioni migliorate con questo assetto regolabile a ghiera.", immagine: "../immagini/coilover.jpg" },
    { nome: "Sospensioni ad Aria", categoria: "assetti", prezzo: 1200, marca: "koni", descrizione: "Comodità assoluta con il nostro kit di sospensioni ad aria.", immagine: "../immagini/sospensioni-aria.jpg" },
    { nome: "Paraurti Anteriore Tuning", categoria: "bodykit", prezzo: 320, marca: "generica", descrizione: "Design aggressivo per un look sportivo e aerodinamico.", immagine: "../immagini/paraurti.jpg" },
    { nome: "Minigonne Laterali", categoria: "bodykit", prezzo: 280, marca: "generica", descrizione: "Ottimizza il profilo laterale della tua auto con stile e funzionalità.", immagine: "../immagini/minigonne.jpg" },
    { nome: "Spoiler Posteriore", categoria: "bodykit", prezzo: 190, marca: "generica", descrizione: "Aumenta la deportanza e completa l'estetica della vettura.", immagine: "../immagini/spoiler.jpg" },
    { nome: "Dischi Freni Sportivi", categoria: "freni", prezzo: 180, marca: "brembo", descrizione: "Massime prestazioni in frenata, anche ad alte temperature.", immagine: "../immagini/dischi-freno.jpg" },
    { nome: "Pastiglie in Kevlar", categoria: "freni", prezzo: 120, marca: "brembo", descrizione: "Maggiore durata e frenata efficace anche in condizioni estreme.", immagine: "../immagini/pastiglie.jpg" },
    { nome: "Kit Freni Completo", categoria: "freni", prezzo: 750, marca: "brembo", descrizione: "Tutto il necessario per aggiornare l'impianto frenante.", immagine: "../immagini/kit-freni.jpg" },
    { nome: "Cerchio in Lega", categoria: "cerchi", prezzo: 150, marca: "oz", descrizione: "Lega leggera, stile sportivo e prezzo contenuto.", immagine: "../immagini/cerchio-lega.jpg" },
    { nome: "Cerchi in Lega Diamantati", categoria: "cerchi", prezzo: 280, marca: "oz", descrizione: "Design sportivo e leggerezza per auto da competizione.", immagine: "../immagini/cerchi-diamantati.jpg" },
    { nome: "Cerchi in Magnesio Alleggeriti", categoria: "cerchi", prezzo: 450, marca: "oz", descrizione: "Il meglio del meglio nel settore, prestazioni elevate e peso ridotto.", immagine: "../immagini/cerchi-magnesio.jpg" }
  ];
  
  // Toggle per i filtri
  filtersToggle.addEventListener('click', function() {
    filtersContainer.classList.toggle('filters-closed');
  });
  
  // Reset dei filtri
  resetFilters.addEventListener('click', function() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    checkboxes.forEach(checkbox => {
      checkbox.checked = false;
    });
    searchInput.value = '';
    displayResults(prodotti);
  });
  
  // Funzione per filtrare i prodotti
  function filtrareProdotti() {
    const termineDiRicerca = searchInput.value.toLowerCase();
    const categorieFiltrate = Array.from(document.querySelectorAll('input[name="categoria"]:checked')).map(el => el.value);
    const prezziFiltrati = Array.from(document.querySelectorAll('input[name="prezzo"]:checked')).map(el => el.value);
    const marcheFiltrate = Array.from(document.querySelectorAll('input[name="marca"]:checked')).map(el => el.value);
    
    let risultatiFiltrati = prodotti;
    
    // Filtra per termine di ricerca
    if (termineDiRicerca.trim() !== '') {
      risultatiFiltrati = risultatiFiltrati.filter(prodotto => 
        prodotto.nome.toLowerCase().includes(termineDiRicerca) || 
        prodotto.descrizione.toLowerCase().includes(termineDiRicerca)
      );
    }
    
    // Filtra per categoria
    if (categorieFiltrate.length > 0) {
      risultatiFiltrati = risultatiFiltrati.filter(prodotto => 
        categorieFiltrate.includes(prodotto.categoria)
      );
    }
    
    // Filtra per prezzo
    if (prezziFiltrati.length > 0) {
      risultatiFiltrati = risultatiFiltrati.filter(prodotto => {
        return prezziFiltrati.some(range => {
          if (range === '0-100') return prodotto.prezzo <= 100;
          if (range === '100-300') return prodotto.prezzo > 100 && prodotto.prezzo <= 300;
          if (range === '300+') return prodotto.prezzo > 300;
          return false;
        });
      });
    }
    
    // Filtra per marca
    if (marcheFiltrate.length > 0) {
      risultatiFiltrati = risultatiFiltrati.filter(prodotto => 
        marcheFiltrate.includes(prodotto.marca)
      );
    }
    
    displayResults(risultatiFiltrati);
  }
  
  // Funzione per visualizzare i risultati
  function displayResults(risultati) {
    if (risultati.length === 0) {
      searchResults.innerHTML = `
        <div class="no-results">
          <p>Nessun risultato trovato.</p>
          <p>Prova a modificare i filtri o a cercare un termine diverso.</p>
        </div>
      `;
      return;
    }
    
    let html = '<div class="catalogo">';
    risultati.forEach(prodotto => {
      // Usa l'immagine vera se disponibile, altrimenti usa un placeholder
      const imgSrc = prodotto.immagine || "-../immagini/logo.jpg";
      
      html += `
        <div class="pezzo">
          <img src="${imgSrc}" alt="${prodotto.nome}" onerror="this.src='https://via.placeholder.com/250x150'">
          <h3>${prodotto.nome}</h3>
          <p>${prodotto.descrizione}</p>
          <p><strong>Prezzo:</strong> ${prodotto.prezzo}€</p>
          <p><strong>Marca:</strong> ${prodotto.marca.charAt(0).toUpperCase() + prodotto.marca.slice(1)}</p>
        </div>
      `;
    });
    html += '</div>';
    
    searchResults.innerHTML = html;
  }
  
  // Event listeners per la ricerca
  searchButton.addEventListener('click', filtrareProdotti);
  applyFilters.addEventListener('click', filtrareProdotti);
  searchInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      filtrareProdotti();
    }
  });
  
  // Inizializza con tutti i prodotti
  displayResults(prodotti);
});